package com.example.artauction;

import java.io.Serializable;

public class Bid implements Serializable {
    private static final long serialVersionUID = 1L;
    private String bidderName;
    private double amount;
    private long timestamp;

    public Bid(String bidderName, double amount) {
        this.bidderName = bidderName;
        this.amount = amount;
        this.timestamp = System.currentTimeMillis();
    }

    public String getBidderName() { return bidderName; }
    public double getAmount() { return amount; }
    public long getTimestamp() { return timestamp; }
}