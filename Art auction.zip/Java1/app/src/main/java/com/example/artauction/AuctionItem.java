package com.example.artauction;

import java.io.Serializable;
import java.util.*;

public class AuctionItem implements Serializable {
    private static final long serialVersionUID = 1L;
    private String title;
    private String artist;
    private double startBid;
    private long endTime;
    private int imageResId;
    private List<Bid> bids;
    private static final Random random = new Random();
    private static final String[] BOT_NAMES = {"Анна", "Борис", "Клара", "Дмитрий", "Елена"};

    public AuctionItem(String title, String artist, double startBid, long endTime, int imageResId) {
        this.title = title;
        this.artist = artist;
        this.startBid = startBid;
        this.endTime = endTime;
        this.imageResId = imageResId;
        this.bids = new ArrayList<>();
        bids.add(new Bid("Начальная ставка", startBid));
    }

    public void placeBid(String bidder, double amount) {
        if (isExpired() || amount <= getCurrentBid()) return;
        bids.add(new Bid(bidder, amount));
    }

    public double getCurrentBid() {
        return bids.get(bids.size() - 1).getAmount();
    }

    public String getCurrentLeader() {
        return bids.get(bids.size() - 1).getBidderName();
    }

    public boolean isExpired() {
        return System.currentTimeMillis() > endTime;
    }

    public long getTimeRemainingMillis() {
        return Math.max(0, endTime - System.currentTimeMillis());
    }

    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public List<Bid> getBids() { return new ArrayList<>(bids); }
    public int getImageResId() { return imageResId; }

    public void simulateBotBids(String userName) {
        if (isExpired() || bids.isEmpty()) return;
        if (random.nextInt(100) < 30) {
            double current = getCurrentBid();
            double increment = 10 + random.nextInt(40);
            String botName = BOT_NAMES[random.nextInt(BOT_NAMES.length)];
            if (!botName.equals(userName)) {
                placeBid(botName, current + increment);
            }
        }
    }
}