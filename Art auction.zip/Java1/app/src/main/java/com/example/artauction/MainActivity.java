package com.example.artauction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private static final String PREF_NAME = "AuctionPrefs";
    private static final String KEY_USER_NAME = "userName";

    private RecyclerView recyclerView;
    private AuctionAdapter adapter;
    private List<AuctionItem> items;
    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        userName = prefs.getString(KEY_USER_NAME, "Друг");

        items = new ArrayList<>();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, 3);
        items.add(new AuctionItem("Звёздная ночь", "Ван Гог", 1000, cal.getTimeInMillis(), R.drawable.starry_night));
        cal.add(Calendar.MINUTE, 2);
        items.add(new AuctionItem("Мона Лиза", "Леонардо да Винчи", 5000, cal.getTimeInMillis(), R.drawable.mona_lisa));

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AuctionAdapter(items, userName, this::showWinDialog);
        recyclerView.setAdapter(adapter);
    }

    private void showWinDialog() {
        runOnUiThread(() -> {
            new AlertDialog.Builder(this)
                    .setTitle("🏆 Поздравляем!")
                    .setMessage(userName + ", вы выиграли аукцион!")
                    .setPositiveButton("Отлично!", (d, w) -> {})
                    .show();
        });
    }
}