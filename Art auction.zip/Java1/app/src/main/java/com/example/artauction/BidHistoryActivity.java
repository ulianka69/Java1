package com.example.artauction;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class BidHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bid_history);

        String title = getIntent().getStringExtra("title");
        ArrayList<String> bidLines = getIntent().getStringArrayListExtra("bids");

        if (bidLines == null) bidLines = new ArrayList<>();
        if (title != null) setTitle("Ставки: " + title);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new BidHistoryAdapter(bidLines));
    }
}