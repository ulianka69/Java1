package com.example.artauction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class BidHistoryAdapter extends RecyclerView.Adapter<BidHistoryAdapter.ViewHolder> {
    private ArrayList<String> bidLines;
    private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    public BidHistoryAdapter(ArrayList<String> bidLines) {
        this.bidLines = (bidLines != null) ? bidLines : new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String line = bidLines.get(position);
        String[] parts = line.split("\\|", 3);

        if (parts.length >= 2) {
            String bidderName = parts[0];
            double amount = Double.parseDouble(parts[1]);
            holder.text1.setText(bidderName + ": $" + String.format("%.0f", amount));

            if (parts.length == 3) {
                try {
                    long timestamp = Long.parseLong(parts[2]);
                    holder.text2.setText(timeFormat.format(new Date(timestamp)));
                } catch (Exception e) {
                    holder.text2.setText("");
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return bidLines.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView text1, text2;
        ViewHolder(View v) {
            super(v);
            text1 = v.findViewById(android.R.id.text1);
            text2 = v.findViewById(android.R.id.text2);
        }
    }
}