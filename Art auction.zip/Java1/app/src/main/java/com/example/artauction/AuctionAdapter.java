package com.example.artauction;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AuctionAdapter extends RecyclerView.Adapter<AuctionAdapter.ViewHolder> {
    private List<AuctionItem> items;
    private String userName;
    private Runnable onWinCallback;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public AuctionAdapter(List<AuctionItem> items, String userName, Runnable onWinCallback) {
        this.items = items;
        this.userName = userName;
        this.onWinCallback = onWinCallback;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_auction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(items.get(position), userName);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleText, artistText, bidText, timerText, bidderText;
        ImageView imageView;
        Button bidButton, historyButton;
        private Runnable timerRunnable;
        private Runnable botRunnable;
        private String currentUserName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.titleText);
            artistText = itemView.findViewById(R.id.artistText);
            bidText = itemView.findViewById(R.id.bidText);
            timerText = itemView.findViewById(R.id.timerText);
            bidderText = itemView.findViewById(R.id.idenText);
            imageView = itemView.findViewById(R.id.imageView);
            bidButton = itemView.findViewById(R.id.bidButton);
            historyButton = itemView.findViewById(R.id.historyButton);
        }

        void bind(AuctionItem item, String userName) {
            this.currentUserName = userName;
            titleText.setText(item.getTitle());
            artistText.setText(item.getArtist());
            bidText.setText("Текущая ставка: $" + new DecimalFormat("#,##0").format(item.getCurrentBid()));
            bidderText.setText("Лидер: " + item.getCurrentLeader());
            imageView.setImageResource(item.getImageResId());

            stopAllTimers();

            if (item.isExpired()) {
                timerText.setText("Аукцион завершён");
                bidButton.setEnabled(false);
                bidButton.setText("Окончен");
                checkWin(item);
            } else {
                updateTimer(item);
                startBotSimulation(item);
            }

            bidButton.setOnClickListener(v -> {
                if (!item.isExpired()) {
                    item.placeBid(currentUserName, item.getCurrentBid() + 10);
                    bidText.setText("Текущая ставка: $" + new DecimalFormat("#,##0").format(item.getCurrentBid()));
                    bidderText.setText("Лидер: " + item.getCurrentLeader());
                }
            });

            historyButton.setOnClickListener(v -> {
                ArrayList<String> bidLines = new ArrayList<>();
                for (Bid bid : item.getBids()) {
                    bidLines.add(bid.getBidderName() + "|" + bid.getAmount() + "|" + bid.getTimestamp());
                }
                Intent intent = new Intent(v.getContext(), BidHistoryActivity.class);
                intent.putStringArrayListExtra("bids", bidLines);
                intent.putExtra("title", item.getTitle());
                v.getContext().startActivity(intent);
            });
        }

        private void updateTimer(AuctionItem item) {
            timerRunnable = () -> {
                if (item.isExpired()) {
                    timerText.setText("Аукцион завершён");
                    bidButton.setEnabled(false);
                    bidButton.setText("Окончен");
                    checkWin(item);
                    return;
                }
                long millis = item.getTimeRemainingMillis();
                long h = TimeUnit.MILLISECONDS.toHours(millis);
                long m = TimeUnit.MILLISECONDS.toMinutes(millis) % 60;
                long s = TimeUnit.MILLISECONDS.toSeconds(millis) % 60;
                timerText.setText(String.format("Осталось: %02d:%02d:%02d", h, m, s));
                mainHandler.postDelayed(timerRunnable, 1000);
            };
            mainHandler.post(timerRunnable);
        }

        private void startBotSimulation(AuctionItem item) {
            botRunnable = () -> {
                if (!item.isExpired()) {
                    item.simulateBotBids(currentUserName);
                    bidText.setText("Текущая ставка: $" + new DecimalFormat("#,##0").format(item.getCurrentBid()));
                    bidderText.setText("Лидер: " + item.getCurrentLeader());
                    mainHandler.postDelayed(botRunnable, 3000);
                }
            };
            mainHandler.post(botRunnable);
        }

        private void checkWin(AuctionItem item) {
            if (onWinCallback != null && currentUserName.equals(item.getCurrentLeader())) {
                mainHandler.post(onWinCallback);
            }
        }

        private void stopAllTimers() {
            if (timerRunnable != null) mainHandler.removeCallbacks(timerRunnable);
            if (botRunnable != null) mainHandler.removeCallbacks(botRunnable);
        }
    }
}