package com.example.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String KEY_CURRENT_INDEX = "current_index";
    private static final String KEY_CORRECT_ANSWERS = "correct_answers";
    private static final String KEY_QUIZ_FINISHED = "quiz_finished";

    private ImageView imageView;
    private Button btn1, btn2, btn3, btn4, btnRestart;
    private TextView resultText;

    private QuizQuestion[] questions = {
            new QuizQuestion(R.drawable.image1, "Илья Репин", new String[]{"Илья Репин", "Виктор Васнецов", "Клод Моне", "Пикассо"}),
            new QuizQuestion(R.drawable.image2, "Клод Моне", new String[]{"Иван Шишкин", "Ренуар", "Бэнкси", "Клод Моне"}),
            new QuizQuestion(R.drawable.image3, "Леонардо да Винче", new String[]{"Леонардо да Винче", "Сальводор Дали", "Валентин Серов", "Боттичелли"}),
            new QuizQuestion(R.drawable.image4, "Рафаэль", new String[]{"Джексон Поллок", "Рафаэль", "Фрида Кало", "Рене Магритт"}),
            new QuizQuestion(R.drawable.image5, "Энди Уорхол", new String[]{"Энди Уорхол", "Архип Куинджи", "Микеланджело", "Рембрандт"}),
            new QuizQuestion(R.drawable.image6, "Веласкес", new String[]{"Я", "Орест Кипренский", "Исаак Левитан", "Веласкес"})
    };

    private int currentQuestionIndex = 0;
    private int correctAnswers = 0;
    private boolean quizFinished = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.ScrollView);
        btn1 = findViewById(R.id.btnOption1);
        btn2 = findViewById(R.id.btnOption2);
        btn3 = findViewById(R.id.btnOption3);
        btn4 = findViewById(R.id.btnOption4);
        resultText = findViewById(R.id.resultText);
        btnRestart = findViewById(R.id.btnRestart);

        // ВОССТАНОВЛЕНИЕ СОСТОЯНИЯ
        if (savedInstanceState != null) {
            currentQuestionIndex = savedInstanceState.getInt(KEY_CURRENT_INDEX, 0);
            correctAnswers = savedInstanceState.getInt(KEY_CORRECT_ANSWERS, 0);
            quizFinished = savedInstanceState.getBoolean(KEY_QUIZ_FINISHED, false);

            // Восстановим интерфейс
            if (quizFinished) {
                showFinalResult();
            } else {
                loadQuestion(currentQuestionIndex);
                resultText.setText("");
                setAnswerButtonsEnabled(true);
            }
        } else {
            // Новый запуск
            loadQuestion(currentQuestionIndex);
        }

        btnRestart.setOnClickListener(v -> restartQuiz());

        View.OnClickListener optionClickListener = v -> handleAnswerClick((Button) v);

        btn1.setOnClickListener(optionClickListener);
        btn2.setOnClickListener(optionClickListener);
        btn3.setOnClickListener(optionClickListener);
        btn4.setOnClickListener(optionClickListener);
    }

    private void handleAnswerClick(Button clickedButton) {
        if (quizFinished) return;

        String selectedAnswer = clickedButton.getText().toString();
        String correctAnswer = questions[currentQuestionIndex].correctAnswer;

        if (selectedAnswer.equals(correctAnswer)) {
            correctAnswers++;
            resultText.setText("Правильно!");
            resultText.setTextColor(0xFF00FF00);
        } else {
            resultText.setText("Неправильно! Правильный ответ: " + correctAnswer);
            resultText.setTextColor(0xFFFF0000);
        }

        setAnswerButtonsEnabled(false);

        new android.os.Handler().postDelayed(() -> {
            currentQuestionIndex++;
            if (currentQuestionIndex < questions.length) {
                loadQuestion(currentQuestionIndex);
                resultText.setText("");
                setAnswerButtonsEnabled(true);
            } else {
                quizFinished = true;
                showFinalResult();
            }
        }, 2000);
    }
    private void showFinalResult() {
        String finalResult = String.format("✅ Вы ответили правильно на %d из %d вопросов!",
                correctAnswers, questions.length);
        resultText.setText(finalResult);
        resultText.setTextColor(0xFF0000FF);
        btnRestart.setVisibility(View.VISIBLE);
    }

    private void loadQuestion(int index) {
        if (index >= questions.length) return;
        QuizQuestion q = questions[index];
        imageView.setImageResource(q.imageResId);
        btn1.setText(q.options[0]);
        btn2.setText(q.options[1]);
        btn3.setText(q.options[2]);
        btn4.setText(q.options[3]);
    }

    private void setAnswerButtonsEnabled(boolean enabled) {
        btn1.setEnabled(enabled);
        btn2.setEnabled(enabled);
        btn3.setEnabled(enabled);
        btn4.setEnabled(enabled);
    }

    private void restartQuiz() {
        currentQuestionIndex = 0;
        correctAnswers = 0;
        quizFinished = false;
        resultText.setText("");
        btnRestart.setVisibility(View.GONE);
        setAnswerButtonsEnabled(true);
        loadQuestion(currentQuestionIndex);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_CURRENT_INDEX, currentQuestionIndex);
        outState.putInt(KEY_CORRECT_ANSWERS, correctAnswers);
        outState.putBoolean(KEY_QUIZ_FINISHED, quizFinished);
    }

    private static class QuizQuestion {
        int imageResId;
        String correctAnswer;
        String[] options;

        QuizQuestion(int imageResId, String correctAnswer, String[] options) {
            this.imageResId = imageResId;
            this.correctAnswer = correctAnswer;
            this.options = options;
        }
    }
}